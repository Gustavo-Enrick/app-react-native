class Apis {
    static async buscaEndereco(cep, setEndereco) {
        try {
            const cepLimpo = cep.replace(/\D/g, '');
            if (cepLimpo.length !== 8) {
                alert('CEP inválido!');
                return;
            }
            const response = await fetch(`https://viacep.com.br/ws/${cepLimpo}/json/`);
            const data = await response.json();
            console.log(data)
            if (data.erro) {
                alert('CEP não encontrado!');
                return;
            }
            setEndereco(data);
        } catch (error) {
            console.error(error);
            alert('Erro ao buscar CEP!');
        }
    }

    static async buscaGatinho(setCat){
        try{
            const response = await fetch('https://api.thecatapi.com/v1/images/search');
            const data = await response.json();
            setCat(data);
        }catch(error){
            console.error(error);
            alert('ERROOUUUUUU');
        }
    }
}
export default Apis;