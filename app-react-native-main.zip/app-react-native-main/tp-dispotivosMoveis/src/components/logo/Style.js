import { StyleSheet } from "react-native";
export default StyleSheet.create({
  logo: {
    width: 700,
    height: 700,
    marginBottom: 20,
  },
});
