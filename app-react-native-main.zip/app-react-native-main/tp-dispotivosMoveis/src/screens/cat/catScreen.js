import React, { useState } from 'react';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View, Text,Image } from 'react-native';
import TextInputBox from '../../components/textInputBox/TextInputBox';
import CustomButton from '../../components/customButtom/CustomButtom';
import Apis from '../../apis/Apis';

export default function catScreen() {
    const [cat, setCat] = useState('');
    return (
        <View style={styles.container}>
            <StatusBar style="auto" />
        
            {cat && cat && (
                <Image source={{ uri: cat.url }} style={styles.catImage} />
            )}

            <CustomButton
                title="Mostrar"
                onPress={() => {
                    Apis.buscaGatinho(setCat);
                }}
                style={styles.button}
            />
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    button: {
        marginTop: 20,
    },
    catImage: {
        width: 200,
        height: 200,
        marginBottom: 20,
    },
    error: {
        color: 'red',
        marginBottom: 20,
    }
});