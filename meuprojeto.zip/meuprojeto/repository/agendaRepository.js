import * as SQLite from 'expo-sqlite';

// Abre o banco com a nova API async
let dbPromise = SQLite.openDatabaseAsync('agenda.db');

// Cria a tabela (apenas uma vez)
const createTable = async () => {
  try {
    const db = await dbPromise;
    await db.execAsync(`
      CREATE TABLE IF NOT EXISTS agenda (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT,
        telefone TEXT
      );
    `);
    console.log('Tabela criada com sucesso.');
  } catch (error) {
    console.error('Erro ao criar tabela:', error);
  }
};

// Busca todos os dados da agenda
const getAgenda = async (setAgenda) => {
  try {
    const db = await dbPromise;
    const rows = await db.getAllAsync('SELECT * FROM agenda');
    console.log('Dados recuperados:', rows);
    setAgenda(rows);
  } catch (error) {
    console.error('Erro ao recuperar dados:', error);
  }
};

// Adiciona novo contato à agenda
const adicionarAgenda = async (nome, telefone, setAgenda) => {
  try {
    const db = await dbPromise;
    await db.runAsync(
      'INSERT INTO agenda (nome, telefone) VALUES (?, ?)',
      nome,
      telefone
    );
    console.log('Dados inseridos com sucesso.');
    await getAgenda(setAgenda); // Atualiza lista após inserir
  } catch (error) {
    console.error('Erro ao inserir dados:', error);
  }
};

// Chama a criação da tabela ao carregar o módulo
createTable();

export { getAgenda, adicionarAgenda };